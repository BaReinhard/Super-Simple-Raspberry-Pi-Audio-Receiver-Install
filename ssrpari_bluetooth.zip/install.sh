#!/bin/bash

echo "Installing ssrpari bluetooth1 Dependencies"
sudo apt-get update -y
sudo apt-get update --fix-missing -y
sudo apt-get -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" install -y pulseaudio-module-bluetooth
# Install the required packages via apt-get
sudo apt-get -y install
git clone https://github.com/bareinhard/super-simple-raspberry-pi-audio-receiver-install
cd super-simple-raspberry-pi-audio-receiver-install
git checkout volumio-plugin
user=`ls /home | head -1`
sudo ./install.sh 4 "$user Bluetooth"
# If you need to differentiate install for armhf and i386 you can get the variable like this
#DPKG_ARCH=`dpkg --print-architecture`
# Then use it to differentiate your install

#requred to end the plugin install
echo "plugininstallend"

